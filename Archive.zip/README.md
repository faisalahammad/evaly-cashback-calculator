# Evaly Cashback Calculator

"Evaly Cashback Calculator" to find out cashback amount for full payment and discount payment amount for partial payment. You could simply find out the cashback and payment amount, so no more CONFUSION!!!

---

### Screenshot
50% cashback preview
![50% Cashback](./images/50.png "50% cashback preview")


100% cashback preview
![50% Cashback](./images/100.png "50% cashback preview")

